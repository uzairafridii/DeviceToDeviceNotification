const functions = require('firebase-functions');

const admin = require('firebase-admin');
admin.initializeApp(functions.config().firebase);

exports.sendNotification = functions.database.ref('/notification/{user_id}/{notification_id}').onWrite((snapShot, context) => {
 
  const user_id = context.params.user_id; 
  const notification = context.params.notification_id;

  console.log('User id ',user_id);
  console.log('push id ', notification);

  if (!snapShot.after.val()) {
            console.log('no fcm found')
            return
        }

 const tokens = admin.database().ref(`/Users/${user_id}/deviceToken`).once('value');
    return tokens.then(result => {
      
          const token = result.val();

        const payload = {
            notification: {
                title: 'New Notification',
                body: 'You have new notification',
                sound: 'default'
            }
        };
        return admin.messaging().sendToDevice(token, payload);

    });


});
    